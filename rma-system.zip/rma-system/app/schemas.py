from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class RMABase(BaseModel):
    product_id: int
    defect_type: str
    initial_status: str

class RMACreate(RMABase):
    pass

class RMA(RMABase):
    id: int

    class Config:
        orm_mode = True