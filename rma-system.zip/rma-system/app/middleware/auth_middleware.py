from fastapi import Request, HTTPException
from fastapi.security import HTTPBearer
from app.jwt_handler import verify_token

auth_scheme = HTTPBearer()

async def authorize_user(request: Request, required_role: str):
    credentials = await auth_scheme(request)
    token_data = verify_token(credentials.credentials)
    if not token_data or token_data['role'] != required_role:
        raise HTTPException(status_code=403, detail="Acesso negado")
    return token_data



def authorize_user(request: Request, required_role: str):
    # Exemplo de como você pode acessar os dados da requisição (como o token de autenticação)
    token = request.headers.get("Authorization")
    if not token:
        raise HTTPException(status_code=401, detail="Token não encontrado")
    
    # Decodifique e valide o token, e verifique o papel do usuário
    user_data = decode_token(token)  # Exemplo de função de decodificação de token
    if user_data["role"] != required_role:
        raise HTTPException(status_code=403, detail="Acesso negado")
    
    return user_data