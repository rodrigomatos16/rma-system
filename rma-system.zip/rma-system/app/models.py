from sqlalchemy import Column, Integer, String
from .database import Base
from app.database import init_db
from app.database import Base

# Inicializar o banco de dados (criar tabelas)
init_db()


class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    password = Column(String)
class RMA(Base):
    __tablename__ = "rmas"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, index=True)
    defect_type = Column(String, index=True)
    initial_status = Column(String)