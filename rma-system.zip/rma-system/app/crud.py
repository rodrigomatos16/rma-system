from app.models import User, RMA  # Importando os modelos
from sqlalchemy.orm import Session
from app.schemas import RMACreate  # Importe o esquema de criação se necessário

# Função para buscar um usuário pelo email
def create_rma_entry(db: Session, product_id: int, defect_type: str, initial_status: str):
    db_rma = RMA(product_id=product_id, defect_type=defect_type, initial_status=initial_status)
    db.add(db_rma)
    db.commit()
    db.refresh(db_rma)
    return db_rma


# Em crud.py
def get_user_by_email(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()

def verify_password(plain_password, hashed_password):
    return plain_password == hashed_password

def create_rma(db: Session, rma: RMACreate):
    db_rma = RMA(**rma.dict())
    db.add(db_rma)
    db.commit()
    db.refresh(db_rma)
    return db_rma