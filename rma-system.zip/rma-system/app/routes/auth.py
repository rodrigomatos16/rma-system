from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.crud import get_user_by_email, verify_password # Importar de 'crud.py'
from app.jwt_handler import create_access_token, create_refresh_token
from fastapi.responses import JSONResponse
from app.database import get_db

router = APIRouter()

# Pydantic models para validação das requisições e respostas
class LoginRequest(BaseModel):
    email: str
    password: str
    role: str  # Recebe o role como parte da requisição

class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    role: str  # Retorna o role do usuário

# Usuário fixo para todos os testes
FIXED_EMAIL = "admin@example.com"
FIXED_PASSWORD = "admin123"

@router.post("", response_model=LoginResponse)
async def login(request: LoginRequest, db: Session = Depends(get_db)):
    # Verifica se o email e senha correspondem ao usuário fixo
    if request.email == FIXED_EMAIL and request.password == FIXED_PASSWORD:
        access_token = create_access_token(user_id=1, role=request.role)
        refresh_token = create_refresh_token(user_id=1)
        return JSONResponse(status_code=200, content={
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "role": request.role  # Retorna o role enviado na requisição
        })

    # Caso contrário, segue com a verificação no banco de dados
    user = get_user_by_email(db, request.email)
    if not user or not verify_password(request.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="E-mail ou senha inválidos")

    if user.role != request.role:  # Verifica se o role corresponde ao que foi enviado
        raise HTTPException(status_code=403, detail="Usuário não autorizado para esse papel")

    # Criação de tokens para o usuário autenticado no banco de dados
    access_token = create_access_token(user_id=user.id, role=user.role)
    refresh_token = create_refresh_token(user_id=user.id)

    return JSONResponse(status_code=200, content={
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "role": user.role  # Retorna o role do usuário
    })
