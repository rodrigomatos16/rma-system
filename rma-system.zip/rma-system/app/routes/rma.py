from fastapi import APIRouter, Depends
from pydantic import BaseModel
from app.middleware.auth_middleware import authorize_user

router = APIRouter()

class RMARequest(BaseModel):
    product_id: int
    defect_type: str
    initial_status: str

@router.post("")
async def register_rma(request: RMARequest, user=Depends(lambda: authorize_user(required_role="funcionario"))):
    return {"message": "RMA registrada com sucesso", "details": request}
