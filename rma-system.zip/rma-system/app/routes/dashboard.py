from fastapi import APIRouter, Depends, HTTPException
from fastapi import Request
from app.middleware.auth_middleware import authorize_user

router = APIRouter()

@router.get("")
async def get_metrics(request: Request):
    try:
        # Remova a parte de autorização para testar
        # Dados simulados para métricas
        data = {
            "status_counts": [
                {"name": "Pendente", "value": 10},
                {"name": "Recebida", "value": 5},
                {"name": "Em Teste", "value": 3},
                {"name": "Concluída", "value": 7},
            ],
            "defects_common": [
                {"type": "Defeito 1", "ocorrencias": 40},
                {"type": "Defeito 2", "ocorrencias": 30},
            ],
            "average_time": [
                {"etapa": "Recebimento", "tempo": 2},
                {"etapa": "Teste", "tempo": 4},
                {"etapa": "Conclusão", "tempo": 3},
            ]
        }

        return data

    except Exception as e:
        print(f"Erro ao obter métricas: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Erro ao obter métricas: {str(e)}")
