from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from app import crud, models, schemas, database
from app.database import get_db  # Import necessário para o Dependency Injection
from fastapi.middleware.cors import CORSMiddleware
from .routes import auth, rma, dashboard  # Importação de rotas
from app.crud import create_rma  # Certifique-se de que esta linha está presente

# Inicialização do FastAPI
app = FastAPI(title="Sistema de Gerenciamento de RMA")

# Configuração do middleware CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Ajuste isso em produção para domínios específicos
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Criar as tabelas do banco de dados
models.Base.metadata.create_all(bind=database.engine)

# Inclui os routers
app.include_router(auth.router, prefix="/auth", tags=["Autenticação"])
app.include_router(dashboard.router, prefix="/metrics", tags=["Métricas"])

# Endpoint de registro de RMA
@app.post("/register-rma/", response_model=schemas.RMA)
def register_rma(rma: schemas.RMACreate, db: Session = Depends(get_db)):
    return create_rma(db=db, rma=rma)
# Endpoint para listar RMAs




