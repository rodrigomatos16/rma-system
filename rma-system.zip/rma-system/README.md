# RMA System

Este projeto é um sistema simples para gerenciar solicitações de RMA (Return Merchandise Authorization).

## Como rodar o projeto

1. Instale as dependências:
    ```bash
    pip install -r requirements.txt
    ```

2. Inicie o servidor:
    ```bash
    uvicorn app.main:app --reload
    ```

3. Acesse a API na URL:
    ```url
    http://127.0.0.1:8000
    ```
